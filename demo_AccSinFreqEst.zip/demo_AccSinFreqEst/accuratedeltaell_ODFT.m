function out = accuratedeltaell_ODFT(magbef, magmid, magaft)


Q = (magbef/magmid);
R = (magbef/magaft);
S = (magaft/magmid);
    
outQ = (1.0-Q)/(1.0+Q);
outR = (3.0+R-sqrt(1.0+(14.0+R)*R))/(2.0*(1.0-R));
outS = 2.0*S/(1.0+S);

rac1 = (magbef*outQ + magmid*outR)/(magbef + magmid);
rac2 = (magmid*outR + magaft*outS)/(magmid + magaft);

if (rac1 <= 0.35) % if low frequency
    out = rac1;
elseif (rac2 >= 0.65) % if high frequency
        out = rac2;
else
        out = (magbef*outQ + magmid*outR + magaft*outS)/(magbef+ magmid + magaft);
end
