%
% This demo file illustrates accurate frequency estimation of individual
% sinusoids in the DFT/ODFT domain
%
% When using this file for educational, research or development purposes,
% please give credit to the paper:
%
% "One-Step Discrete Fourier Transform-based Sinusoid Frequency Estimation
%  Under Full-Bandwidth Quasi-Harmonic Interference, MDPI Acoustics, 2023"
%
% Authors: Joao Silva, Marco Oliveira, Andre Saraiva, and Anibal Ferreira
% contact e-mail:  ajf(at)fe.up.pt
% August 2023
%

N=1024; N2=N/2;
D=(N-1)/2;
A=1;
sinwin = sin(pi/N*([0:N-1]+0.5)); % Sine window
direxp = exp(-1j*pi*[0:N-1]/N); % complex vector necessary for ODFT computation

noiselevel = 15.0; % in dB
sigma=sqrt(2*A^2)/(sqrt(2)*10^(noiselevel/20));

% two FM modulated sinusoids
samples=N2*100;
t=[0:samples-1];
wave=A*(sin(2*pi*25.1*t/1024+12.0*sin(2*pi*t/10240)))+sin(2*pi*30.9*t/1024-12.0*sin(2*pi*t/10240));

figure(1)
subplot(2,1,1)
[Y,F,T,P] = spectrogram(wave, sinwin, N/2, N, 1); % Fs=1 Hz to simplify axis scale
surf(T/N2,F*N,10*log10(abs(P)),'EdgeColor','none');
axis xy; axis tight; colormap(jet); view(0,90);
ylabel('FREQUENCY (DFT bins) \rightarrow');
axis([1 99 22 35]);

index=1:N;
counter=0;
traject=[];
while (index(N)<=samples)
    counter=counter+1;
    x=wave(index);
    noise=sigma*randn(1, N);
%         disp('SNR')
%         20*log10(std(x)/std(noise)) % just to check
%         pause;
    x=x+noise;
    x = x.*sinwin;
    X = x.*direxp;  % this is sub-optimal ODFT computation !
    X=abs(fft(X));
    minlev=max(X)/2;
    [peaks, locat]=findpeaks(X(1:N2),'minpeakheight',minlev);
    npeaks=length(locat);
    for k=1:npeaks
        traject(counter, k) = locat(k) -1 + accuratedeltaell_ODFT(X(locat(k)-1), X(locat(k)), X(locat(k)+1)); % -1 is because index in Matlab starts at 1 and not at 0
    end
    
    index=index+N2;
end
subplot(2,1,2)
plot([1:counter], traject([1:counter],:),'*');
hold on
plot([1:counter], 25.1+1.2*cos(2*pi*D*(1:counter)/10240),'g',[1:counter], 30.9-1.2*cos(2*pi*D*(1:counter)/10240),'g');
hold off
xlabel('TIME (frames) \rightarrow');
ylabel('FREQUENCY (DFT bins) \rightarrow');
axis([1 99 23 33])

% a short singing signal with vibrato (11 partials are considered)
figure(2)
wave=audioread('fugees22.wav');
wave=wave.';
samples=length(wave);
t=[0:samples-1];

subplot(2,1,1)
[Y,F,T,P] = spectrogram(wave, sinwin, N/2, N, 1); % Fs=1 Hz to simplify axis scale
surf(T/N2,F*N,10*log10(abs(P)),'EdgeColor','none');
axis xy; axis tight; colormap(jet); view(0,90);
ylabel('FREQUENCY (DFT bins) \rightarrow');
axis([1 42 1 220]);


index=1:N;
counter=0;
traject=[];
while (index(N)<=samples)
    counter=counter+1;
    x=wave(index);
    noise=sigma*randn(1, N);
    x = x.*sinwin;
    X = x.*direxp;  % this is sub-optimal ODFT computation !
    X=abs(fft(X));
    shift=8;
    [peaks, locat]=findpeaks(20*log10(X(shift:N2/2)),'minpeakheight',-20, 'minpeakdistance',8, 'npeaks', 11);
    locat=locat+shift-1;
    npeaks=length(locat);
    for k=1:npeaks
        traject(counter, k) = locat(k) -1 + accuratedeltaell_ODFT(X(locat(k)-1), X(locat(k)), X(locat(k)+1)); % -1 is because index in Matlab starts at 1 and not at 0
    end
    
    index=index+N2;
end
subplot(2,1,2)
plot([1:counter], traject([1:counter],:),'-*');
xlabel('TIME (frames) \rightarrow');
ylabel('FREQUENCY (DFT bins) \rightarrow');
axis([1 42 1 220])



